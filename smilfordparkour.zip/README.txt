Thank you for downloading Smilford Parkour!

Controls:
	Arrow forward to move forward
	Arrows left/right to turn left/right
	Spacebar to jump

How to play:
	Jump across the logs on the raging river to reach the yellow platform on the other side!
	Try not to fall into the river!
	You have infinite splashes. No need to worry!
	Once you win, you may press E to save your results. Results will be saved into the "logs" folder as "[seed#].smf".

Upcoming features:
	Moving logs

About:
	smilfordparkourSE.exe is the default game we all love, for casual players and speedrunners.

	smilfordparkourINF.exe is the infinite version, go for the longest time!